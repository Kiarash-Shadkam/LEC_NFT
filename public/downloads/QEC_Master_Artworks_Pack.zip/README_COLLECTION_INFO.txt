=======================================================
QUANTUM ENGRAVING COLLECTION (QEC) — MASTER ARTWORKS PACK
=======================================================
Creator: Alireza Mahdipour Shadkam
Affiliation: Nanophotonics Group, Faculty of Electrical and Computer Engineering, University of Tabriz
Thesis: Modeling and implementation of laser engraving considering the impact of layers material
Supervisors: Dr. Hamed Baghban, Dr. Hadi Veladi
Date: February 2026

INCLUDED ASSETS:
1. 01_Visual_Identity/
   - QEC_Collection_Logo_1024x1024.jpg (Square 1:1 Profile Avatar)
   - QEC_Collection_Banner_1376x768.jpg (Wide 16:9 Collection Header)

2. 02_Artworks/
   - High-resolution Master NFT Artworks (1/1 Single Editions)
   - Pure fine art without text, frames, borders, or watermarks.

3. 03_Metadata_JSON/
   - ERC-721 standard metadata for OpenSea / Polygon.
=======================================================
